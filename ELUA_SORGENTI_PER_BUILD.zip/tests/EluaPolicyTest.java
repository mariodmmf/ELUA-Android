package it.spunto.companion;

public final class EluaPolicyTest {
    private static int passed;
    private static void yes(boolean value, String why) {
        if (!value) throw new AssertionError(why);
        passed++;
    }
    public static void main(String[] args) {
        yes(!EluaPolicy.allowed("AI",false,true,true,true,false),"consent off blocks");
        yes(!EluaPolicy.allowed("AI",true,false,true,true,false),"master stop blocks");
        yes(!EluaPolicy.allowed("AI",true,true,false,true,false),"app not allowed blocks");
        yes(!EluaPolicy.allowed("AI",true,true,true,false,false),"category muted blocks");
        yes(!EluaPolicy.allowed("AI",true,true,true,true,true),"sensitive screen blocks");
        yes(EluaPolicy.allowed("AI",true,true,true,true,false),"explicit opt in works");
        yes(!EluaPolicy.isKnownCategory("Password"),"unknown never added");
        yes(EluaPolicy.cooldown(-10)==60_000L,"cooldown clamps low");
        yes(EluaPolicy.cooldown(7)==360_000L,"cooldown clamps high");
        yes(EluaPolicy.offerForScore(-2,12),"slightly disliked still shown");
        yes(!EluaPolicy.offerForScore(-9,7),"low relevance suppressed");
        yes(EluaPolicy.offerForScore(-9,6),"occasional discovery preserved");
        yes(EluaPolicy.dueSoon(100, 0),"due soon detected");
        yes(!EluaPolicy.dueSoon(0,0),"undated not due");
        yes(EluaPolicy.expired(100, 1010, 200),"old category expired");
        yes(!EluaPolicy.expired(100, 250, 200),"recent category not expired");
        System.out.println("EluaPolicyTest PASS ("+passed+" assertions)");
    }
}
