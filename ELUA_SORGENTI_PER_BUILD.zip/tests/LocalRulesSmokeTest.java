package it.spunto.companion;

/** Simple offline JVM smoke test, no Android SDK required. */
public final class LocalRulesSmokeTest {
    private static void expect(boolean yes, String reason) {
        if (!yes) throw new AssertionError(reason);
    }
    public static void main(String[] args) {
        expect(LocalRules.isSensitive("Codice OTP 123456"), "should protect OTP screen");
        expect(LocalRules.isSensitive("Il mio IBAN IT60X0542811101000000123456"), "should protect IBAN");
        expect(LocalRules.isSensitive("Saldo disponibile 900 euro"), "should protect account");
        expect(LocalRules.analyze("Qui il mio conto corrente e un softbox nel profilo") == null,
            "must not suggest from obviously sensitive content");
        expect(LocalRules.analyze("Ecco uno schema luce con softbox laterale per la prossima produzione fotografica") != null,
            "should recognize photography");
        expect(LocalRules.analyze("Google Ads e ROAS con strategie per migliorare il mio account adv questa settimana") != null,
            "should recognize marketing");
        expect(LocalRules.analyze("Utilizzando Magic V5 e un sistema HONOR vediamo cosa succede agli smartphone pieghevoli") != null,
            "should recognize devices");
        expect(LocalRules.analyze("Congratulazioni hai vinto: riscatta il premio! Clicca qui sul link per ottenerlo") != null,
            "should warn for suspicious prize framing");
        expect(LocalRules.analyze("Questo post parla di qualcosa di normale che non corrisponde ai temi configurati") == null,
            "should avoid random popups");
        System.out.println("LocalRulesSmokeTest PASS (9 assertions)");
    }
}
