package it.spunto.companion;
public final class EluaCutoutPlacementTest {
    static int pass=0;
    static void check(boolean yes, String label) { if(!yes)throw new AssertionError(label); pass++; }
    public static void main(String[] args) {
        EluaCutoutPlacement.Position a=EluaCutoutPlacement.place(400,34,200,35,235,12,8);
        check(a.x==83,"cover centered"); check(a.y==43,"below camera");
        EluaCutoutPlacement.Position b=EluaCutoutPlacement.place(880,45,835,42,235,12,8);
        check(b.x==633,"folded outboard clamp"); check(b.y==53,"below bar");
        EluaCutoutPlacement.Position c=EluaCutoutPlacement.place(880,56,-1,0,235,12,8);
        check(c.x==323,"no notch -> centered"); check(c.y==64,"safe below bar");
        EluaCutoutPlacement.Position d=EluaCutoutPlacement.place(300,30,25,42,235,12,8);
        check(d.x==12,"left camera clamp"); check(d.y==50,"camera lower than bar");
        EluaCutoutPlacement.Position e=EluaCutoutPlacement.place(500,31,250,31,235,12,8);
        check(e.x>=12 && e.x+235<=488,"safe horizontal bounds");
        System.out.println("EluaCutoutPlacementTest PASS: "+pass+" checks");
    }
}
