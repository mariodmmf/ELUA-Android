package it.spunto.companion;

/** Pure geometry for a safe, non-system Halo chip near—but never inside—the cutout. */
final class EluaCutoutPlacement {
    static final class Position {
        final int x, y;
        Position(int x, int y) { this.x=x; this.y=y; }
    }
    static Position place(int screenWidth, int statusBarBottom,
                          int cutoutCenterX, int cutoutBottom,
                          int chipWidth, int sideMargin, int gap) {
        int safeWidth = Math.max(1, screenWidth);
        int usableWidth = Math.min(chipWidth, Math.max(1, safeWidth - 2 * sideMargin));
        // The camera may be centered on the cover display or off-center unfolded.
        int center = cutoutCenterX >= 0 ? cutoutCenterX : safeWidth / 2;
        int proposed = center - usableWidth / 2;
        int x = clamp(proposed, sideMargin, Math.max(sideMargin, safeWidth - sideMargin - usableWidth));
        int y = Math.max(Math.max(0, statusBarBottom), Math.max(0, cutoutBottom)) + Math.max(0, gap);
        return new Position(x, y);
    }
    static int clamp(int v, int min, int max) {return Math.min(Math.max(v,min), Math.max(min,max));}
    private EluaCutoutPlacement() {}
}
