package it.spunto.companion;

/** Device-first policy: no ML or hidden device actions. Pure Java for deterministic tests. */
final class EluaPolicy {
    private EluaPolicy() { }
    static final String[] TOPICS = {"Fotografia", "Advertising", "AI", "Tecnologia", "Gaming", "Viaggi", "Creatività", "Attenzione digitale"};
    static final long[] COOLDOWNS = {60_000L, 180_000L, 360_000L};

    static boolean allowed(String category, boolean consent, boolean enabled,
                           boolean appAllowed, boolean topicAllowed, boolean sensitive) {
        return consent && enabled && appAllowed && topicAllowed && !sensitive && isKnownCategory(category);
    }
    static boolean isKnownCategory(String category) {
        if (category == null) return false;
        for (String item : TOPICS) if (item.equals(category)) return true;
        return false;
    }
    static long cooldown(int level) {
        return COOLDOWNS[Math.max(0, Math.min(COOLDOWNS.length - 1, level))];
    }
    // Explicit negative feedback reduces ranking; dismissal alone is a very weak signal.
    static boolean offerForScore(int score, int fingerprint) {
        return score > -5 || Math.floorMod(fingerprint, 3) == 0;
    }
    static boolean dueSoon(long dateMillis, long nowMillis) {
        return dateMillis > 0 && dateMillis <= nowMillis + 2L * 24 * 60 * 60 * 1000;
    }
    static boolean expired(long recordedAt, long now, long ttlMillis) {
        return recordedAt > 0 && now - recordedAt > ttlMillis;
    }
}
