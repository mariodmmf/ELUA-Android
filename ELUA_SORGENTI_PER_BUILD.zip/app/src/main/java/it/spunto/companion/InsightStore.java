package it.spunto.companion;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Local encrypted, small memory for USER-CONFIRMED notes, feedback and anonymous
 * category sightings. NEVER stores observed screen text, message text, URLs or screenshots.
 * AndroidKeyStore AES/GCM key is not exportable. No plaintext fallback.
 */
final class InsightStore {
    private static final String KEY_ALIAS = "spunto_v5_local_notes_key_v1";
    private static final byte[] MAGIC = "SV5A1".getBytes(StandardCharsets.US_ASCII);
    private static final int IV_LEN = 12;
    private static final int MAX_FILE_BYTES = 750_000;
    private static final int MAX_NOTES = 120;
    private static final long SIGHTING_RECHECK_MS = 6L * 60L * 60L * 1000L;
    private static final long SIGHTING_EXPIRY_MS = 14L * 24L * 60L * 60L * 1000L;
    private final AtomicFile file;

    static final class Observation {
        final boolean multipleApps;
        final int distinctApps;
        Observation(boolean crossApp, int count) {
            multipleApps = crossApp;
            distinctApps = count;
        }
    }

    InsightStore(Context context) {
        file = new AtomicFile(new File(context.getFilesDir(), "spunto_memory_v1.bin"));
    }

    synchronized void addNote(String text) {
        String clean = text == null ? "" : text.trim();
        if (clean.length() == 0 || clean.length() > 1200) {
            throw new IllegalArgumentException("La nota deve essere tra 1 e 1200 caratteri.");
        }
        try {
            JSONObject doc = load();
            JSONArray notes = doc.optJSONArray("notes");
            if (notes == null) notes = new JSONArray();
            JSONObject note = new JSONObject();
            note.put("when", System.currentTimeMillis());
            note.put("type", "manual");
            note.put("category", "Nota personale");
            note.put("text", clean);
            notes.put(note);
            doc.put("notes", trim(notes, MAX_NOTES));
            persist(doc);
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized void saveSuggestion(LocalRules.Suggestion suggestion, String origin) {
        // Stores only our own boilerplate suggestion. Never save third-party screen content.
        try {
            JSONObject doc = load();
            JSONArray notes = doc.optJSONArray("notes");
            if (notes == null) notes = new JSONArray();
            JSONObject note = new JSONObject();
            note.put("when", System.currentTimeMillis());
            note.put("type", "elua");
            note.put("category", suggestion.category);
            note.put("origin", origin);
            note.put("text", suggestion.message);
            notes.put(note);
            doc.put("notes", trim(notes, MAX_NOTES));
            persist(doc);
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized JSONArray getNotes() {
        try {
            JSONArray notes = load().optJSONArray("notes");
            return notes == null ? new JSONArray() : notes;
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized void deleteNoteAt(int index) {
        try {
            JSONObject doc = load();
            JSONArray notes = doc.optJSONArray("notes");
            if (notes == null || index < 0 || index >= notes.length()) return;
            JSONArray output = new JSONArray();
            for (int i = 0; i < notes.length(); i++) if (i != index) output.put(notes.get(i));
            doc.put("notes", output);
            persist(doc);
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized void feedback(String category, String label) {
        // Counts are weak ranking signals, not ground truth about personal preferences.
        if (!label.equals("useful") && !label.equals("dismiss") && !label.equals("not_relevant")) return;
        try {
            JSONObject doc = load();
            JSONObject feedback = doc.optJSONObject("feedback");
            if (feedback == null) feedback = new JSONObject();
            JSONObject stat = feedback.optJSONObject(category);
            if (stat == null) stat = new JSONObject();
            stat.put(label, Math.min(1000, stat.optInt(label, 0) + 1));
            feedback.put(category, stat);
            doc.put("feedback", feedback);
            persist(doc);
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized int score(String category) {
        try {
            JSONObject stats = load().optJSONObject("feedback");
            JSONObject stat = stats == null ? null : stats.optJSONObject(category);
            if (stat == null) return 0;
            int result = stat.optInt("useful", 0) * 2 - stat.optInt("not_relevant", 0) * 2
                - stat.optInt("dismiss", 0) / 4;
            return Math.max(-10, Math.min(10, result));
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized Observation seen(String category, String packageName) {
        try {
            JSONObject doc = load();
            JSONObject seen = doc.optJSONObject("seen");
            if (seen == null) seen = new JSONObject();
            JSONObject record = seen.optJSONObject(category);
            long now = System.currentTimeMillis();
            if (record == null || now - record.optLong("last", 0) > SIGHTING_EXPIRY_MS) {
                record = new JSONObject();
                record.put("apps", new JSONObject());
            }
            JSONObject apps = record.optJSONObject("apps");
            if (apps == null) apps = new JSONObject();
            long previous = apps.optLong(packageName, 0);
            // Limit writes and footprint: one anonymous category+app sighting per 6 hours.
            if (now - previous > SIGHTING_RECHECK_MS) {
                apps.put(packageName, now);
                record.put("apps", apps);
                record.put("last", now);
                seen.put(category, record);
                doc.put("seen", seen);
                persist(doc);
            }
            return new Observation(apps.length() >= 2, apps.length());
        } catch (Exception e) { throw storageError(e); }
    }

    /** Only user-authored commitments, never tasks inferred from observed screen text. */
    synchronized void addCommitment(String title, long dueAt) {
        String clean = title == null ? "" : title.trim();
        if (clean.isEmpty() || clean.length() > 160) {
            throw new IllegalArgumentException("L'impegno deve essere tra 1 e 160 caratteri.");
        }
        if (dueAt < 0) throw new IllegalArgumentException("Data non valida.");
        try {
            JSONObject doc = load();
            JSONArray tasks = doc.optJSONArray("tasks");
            if (tasks == null) tasks = new JSONArray();
            JSONObject task = new JSONObject();
            task.put("title", clean);
            task.put("added", System.currentTimeMillis());
            task.put("due", dueAt);
            task.put("done", false);
            tasks.put(task);
            doc.put("tasks", trim(tasks, 90));
            persist(doc);
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized JSONArray getCommitments() {
        try {
            JSONArray tasks = load().optJSONArray("tasks");
            return tasks == null ? new JSONArray() : tasks;
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized void completeCommitment(int index, boolean done) {
        try {
            JSONObject doc = load();
            JSONArray tasks = doc.optJSONArray("tasks");
            if (tasks == null || index < 0 || index >= tasks.length()) return;
            JSONObject task = tasks.optJSONObject(index);
            if (task == null) return;
            task.put("done", done);
            doc.put("tasks", tasks);
            persist(doc);
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized void deleteCommitment(int index) {
        try {
            JSONObject doc = load();
            JSONArray tasks = doc.optJSONArray("tasks");
            if (tasks == null || index < 0 || index >= tasks.length()) return;
            JSONArray output = new JSONArray();
            for (int i = 0; i < tasks.length(); i++) if (i != index) output.put(tasks.get(i));
            doc.put("tasks", output);
            persist(doc);
        } catch (Exception e) { throw storageError(e); }
    }

    /** Anonymous topical sightings: no snippets, messages, screenshots or URLs. */
    synchronized JSONArray getRadar() {
        try {
            JSONObject seen = load().optJSONObject("seen");
            JSONArray result = new JSONArray();
            if (seen == null) return result;
            long now = System.currentTimeMillis();
            java.util.Iterator<String> keys = seen.keys();
            while (keys.hasNext()) {
                String category = keys.next();
                JSONObject item = seen.optJSONObject(category);
                if (item == null || !EluaPolicy.isKnownCategory(category) ||
                    EluaPolicy.expired(item.optLong("last", 0), now, SIGHTING_EXPIRY_MS)) continue;
                JSONObject row = new JSONObject();
                row.put("category", category);
                row.put("last", item.optLong("last", 0));
                JSONObject apps = item.optJSONObject("apps");
                row.put("apps", apps == null ? 0 : apps.length());
                result.put(row);
            }
            return result;
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized JSONObject getFeedbackSummary() {
        try {
            JSONObject feedback = load().optJSONObject("feedback");
            return feedback == null ? new JSONObject() : feedback;
        } catch (Exception e) { throw storageError(e); }
    }

    synchronized void clear() {
        try {
            // Remove records while keeping the key alive for future entries.
            persist(new JSONObject());
        } catch (Exception e) { throw storageError(e); }
    }

    private static JSONArray trim(JSONArray from, int lastN) throws Exception {
        JSONArray trimmed = new JSONArray();
        for (int i = Math.max(0, from.length() - lastN); i < from.length(); i++)
            trimmed.put(from.get(i));
        return trimmed;
    }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        SecretKey existing = (SecretKey) store.getKey(KEY_ALIAS, null);
        if (existing != null) return existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .setKeySize(256).build());
        return generator.generateKey();
    }

    private JSONObject load() throws Exception {
        byte[] data;
        try {
            data = file.readFully();
        } catch (java.io.FileNotFoundException absent) {
            return new JSONObject();
        }
        if (data.length <= MAGIC.length + IV_LEN || data.length > MAX_FILE_BYTES)
            throw new IllegalStateException("Archivio non valido: lettura bloccata.");
        for (int i = 0; i < MAGIC.length; i++)
            if (data[i] != MAGIC[i]) throw new IllegalStateException("Formato archivio sconosciuto.");
        byte[] iv = Arrays.copyOfRange(data, MAGIC.length, MAGIC.length + IV_LEN);
        byte[] encrypted = Arrays.copyOfRange(data, MAGIC.length + IV_LEN, data.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        byte[] plain = cipher.doFinal(encrypted);
        return new JSONObject(new String(plain, StandardCharsets.UTF_8));
    }

    private void persist(JSONObject doc) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = cipher.getIV();
        if (iv == null || iv.length != IV_LEN) throw new IllegalStateException("IV non valido");
        byte[] encrypted = cipher.doFinal(doc.toString().getBytes(StandardCharsets.UTF_8));
        if (MAGIC.length + IV_LEN + encrypted.length > MAX_FILE_BYTES)
            throw new IllegalStateException("Archivio pieno, esporta o elimina note.");
        byte[] all = new byte[MAGIC.length + IV_LEN + encrypted.length];
        System.arraycopy(MAGIC, 0, all, 0, MAGIC.length);
        System.arraycopy(iv, 0, all, MAGIC.length, IV_LEN);
        System.arraycopy(encrypted, 0, all, MAGIC.length + IV_LEN, encrypted.length);
        FileOutputStream writer = null;
        try {
            writer = file.startWrite();
            writer.write(all);
            file.finishWrite(writer);
        } catch (Exception e) {
            if (writer != null) file.failWrite(writer);
            throw e;
        }
    }

    private IllegalStateException storageError(Exception error) {
        return new IllegalStateException("Impossibile accedere alla memoria cifrata: operazione annullata. " +
            error.getClass().getSimpleName());
    }
}
