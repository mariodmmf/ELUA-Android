package it.spunto.companion;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.view.WindowInsets;
import android.view.WindowMetrics;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayDeque;

/**
 * In-app opt-in accessibility companion. Never executes gestures or types into another app.
 * No Internet permission; no raw screen text is persisted.
 */
public final class CompanionAccessibilityService extends AccessibilityService {
    private static final long ANALYZE_INTERVAL_MS = 3500L;
    private static final int MAX_NODES = 240;
    private static final int MAX_CHARS = 2200;
    private static CompanionAccessibilityService connected;

    private final Handler main = new Handler(Looper.getMainLooper());
    private long lastScan;
    private long lastSuggestion;
    private int lastFingerprint;
    private WindowManager wm;
    private View overlay;
    private Runnable dismissTask;
    private InsightStore store;

    static void dismissFromSettings() {
        // Same-process service only. If not connected, privacy gate in onAccessibilityEvent
        // still prevents further observations.
        if (connected != null) connected.removeOverlay();
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        connected = this;
        store = new InsightStore(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        // Own Activity and popup events are never an observation source.
        if (pkg.equals(getPackageName())) return;
        SharedPreferences p = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        if (!p.getBoolean(MainActivity.CONSENT, false) ||
                !p.getBoolean(MainActivity.ACTIVE, false) ||
                !MainActivity.APPS.containsKey(pkg) ||
                !p.getBoolean("allow:" + pkg, false)) {
            removeOverlay();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        long minGap = EluaPolicy.cooldown(p.getInt("intensity", 1));
        if (now - lastScan < ANALYZE_INTERVAL_MS ||
                (lastSuggestion > 0 && now - lastSuggestion < minGap)) return;
        lastScan = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { removeOverlay(); return; }
        try {
            if (root.getPackageName() == null || !pkg.contentEquals(root.getPackageName())) { removeOverlay(); return; }
            // Read only noneditable text nodes and never read node content descriptions.
            String visible = readNonEditableText(root);
            if (visible == null || visible.length() < 40 || LocalRules.isSensitive(visible)) {
                // A screen that became unreadable or sensitive invalidates the previous suggestion.
                removeOverlay();
                return;
            }
            int fingerprint = (pkg + visible).hashCode();
            if (fingerprint == lastFingerprint) return;
            LocalRules.Suggestion base = LocalRules.analyze(visible);
            if (base == null) return;
            if (!EluaPolicy.allowed(base.category, p.getBoolean(MainActivity.CONSENT, false),
                p.getBoolean(MainActivity.ACTIVE, false),
                p.getBoolean("allow:" + pkg, false),
                p.getBoolean("topic:" + base.category, true), false)) return;

            if (store == null) store = new InsightStore(this);
            InsightStore.Observation observation;
            int score;
            try {
                observation = store.seen(base.category, pkg);
                score = store.score(base.category);
            } catch (RuntimeException storageFailure) {
                // Fail closed: if encrypted memory cannot open, do not observe or suggest.
                removeOverlay();
                return;
            }

            LocalRules.Suggestion proposal = base;
            if (observation.multipleApps) {
                proposal = new LocalRules.Suggestion(base.category,
                    "Ho notato contenuti di «" + base.category + "» in più app autorizzate. Potrebbe essere un interesse da approfondire, senza fretta.",
                    base.prompt);
            }
            // A repeated 'not relevant' explicitly given by the user is a ranking signal.
            // Never suppress all suggestions indefinitely just because the user ignored one.
            if (!EluaPolicy.offerForScore(score, fingerprint)) return;
            lastFingerprint = fingerprint;
            lastSuggestion = now;
            String excerpt = visible.length() > 380 ? visible.substring(0, 380) + "…" : visible;
            showSuggestion(proposal, excerpt, MainActivity.APPS.get(pkg));
        } finally {
            root.recycle();
        }
    }

    private String readNonEditableText(AccessibilityNodeInfo root) {
        StringBuilder output = new StringBuilder();
        ArrayDeque<AccessibilityNodeInfo> pending = new ArrayDeque<>();
        pending.add(root);
        int visited = 0;
        while (!pending.isEmpty() && visited++ < MAX_NODES) {
            AccessibilityNodeInfo node = pending.removeFirst();
            if (node.isPassword()) {
                if (node != root) node.recycle();
                while (!pending.isEmpty()) pending.removeFirst().recycle();
                // Any password field aborts the entire scan, rather than merely skipping the field.
                return null;
            }
            if (!node.isEditable() && node.isVisibleToUser()) {
                CharSequence text = node.getText();
                if (text != null && text.length() > 0 && output.length() < MAX_CHARS) {
                    int remaining = MAX_CHARS - output.length();
                    output.append(text, 0, Math.min(text.length(), remaining)).append(' ');
                }
            }
            for (int i = 0; i < node.getChildCount(); ++i) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) pending.addLast(child);
            }
            if (node != root) node.recycle();
        }
        boolean incomplete = !pending.isEmpty();
        while (!pending.isEmpty()) pending.removeFirst().recycle();
        // If the tree was too complex to check, never propose from a partial scan.
        return incomplete ? null : output.toString().trim();
    }

    /** Small by default; user expands before acting. No automatic content sharing. */
    private void showSuggestion(LocalRules.Suggestion suggestion, String excerpt, String origin) {
        // Halo is a user-selectable presentation mode: no extra permissions,
        // no independent screen capture, no always-on microphoning.
        boolean halo = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .getBoolean(MainActivity.HALO_MODE, false);
        if (halo) showHalo(suggestion, excerpt, origin);
        else showEluaOverlay(suggestion, excerpt, origin, false);
    }

    /** Compact capsule located BELOW the hardware cutout; never imitates SystemUI. */
    private void showHalo(LocalRules.Suggestion s, String excerpt, String origin) {
        removeOverlay();
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm == null) return;
        LinearLayout pill = new LinearLayout(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(14), dp(2), dp(6), dp(2));
        int accent = "Attenzione digitale".equals(s.category) ? EluaStyle.AMBER : EluaStyle.MINT;
        pill.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE, accent, 29));
        pill.setElevation(dp(12));
        pill.setContentDescription("Elua Halo: " + s.category + ". Tocca per leggere il suggerimento");
        TextView mark = EluaStyle.wordmark(this, 17);
        mark.setIncludeFontPadding(false);
        pill.addView(mark);
        TextView label = text("   ·   " + s.category, 11, accent, true);
        label.setMaxLines(1);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pill.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = text("×", 22, EluaStyle.SUBTEXT, false);
        close.setGravity(Gravity.CENTER);
        close.setMinWidth(dp(43));
        close.setMinHeight(dp(48));
        close.setContentDescription("Chiudi Halo senza aprire");
        close.setOnClickListener(v -> removeOverlay());
        pill.addView(close);
        pill.setOnClickListener(v -> showEluaOverlay(s, excerpt, origin, true));
        int chipWidth = Math.min(dp(235), Math.max(dp(120),
            getResources().getDisplayMetrics().widthPixels - dp(24)));
        WindowManager.LayoutParams params = overlayParams(chipWidth, dp(54), true);
        try { wm.addView(pill, params); overlay = pill; }
        catch (RuntimeException fail) { overlay = null; return; }
        dismissTask = this::removeOverlay;
        main.postDelayed(dismissTask, 9_000L);
    }

    private WindowManager.LayoutParams overlayParams(int width, int height, boolean cutoutAnchor) {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            width, height, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int statusBottom = dp(32);
        int center = -1;
        int cutoutBottom = 0;
        if (Build.VERSION.SDK_INT >= 30 && wm != null) {
            try {
                WindowMetrics metrics = wm.getCurrentWindowMetrics();
                screenWidth = metrics.getBounds().width();
                WindowInsets insets = metrics.getWindowInsets();
                statusBottom = insets.getInsetsIgnoringVisibility(WindowInsets.Type.statusBars()).top;
                android.view.DisplayCutout cutout = insets.getDisplayCutout();
                if (cutout != null) {
                    for (Rect rect : cutout.getBoundingRects()) {
                        if (rect.top <= statusBottom + dp(16) && rect.bottom >= 0) {
                            center = rect.centerX();
                            cutoutBottom = Math.max(cutoutBottom, rect.bottom);
                            break;
                        }
                    }
                }
            } catch (RuntimeException ignored) {
                // OEM may restrict metrics for accessibility overlays; use safe defaults.
            }
        }
        // On unfolded display, a corner camera anchors the capsule to that side.
        // No notch reported: center the capsule below the status bar.
        EluaCutoutPlacement.Position p = EluaCutoutPlacement.place(
            screenWidth, statusBottom, cutoutAnchor ? center : -1,
            cutoutBottom, width, dp(12), dp(cutoutAnchor ? 8 : 12));
        params.x = p.x;
        params.y = p.y;
        return params;
    }

    private void showEluaOverlay(LocalRules.Suggestion s, String excerpt, String origin, boolean expanded) {
        removeOverlay();
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm == null) return;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(13), dp(16), dp(13));
        card.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE, EluaStyle.BORDER, 23));
        card.setElevation(dp(13));
        card.setContentDescription("Suggerimento contestuale di Elua " + s.category);

        LinearLayout title = new LinearLayout(this);
        title.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = EluaStyle.wordmark(this, 19);
        title.addView(mark);
        TextView brand = text("   ·  " + s.category.toUpperCase(java.util.Locale.ITALIAN),
            11, EluaStyle.MINT, true);
        brand.setLetterSpacing(.08f);
        title.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = text("×", 28, EluaStyle.SUBTEXT, false);
        close.setGravity(Gravity.CENTER);
        close.setMinWidth(dp(48));
        close.setMinHeight(dp(48));
        close.setContentDescription("Chiudi il suggerimento");
        close.setOnClickListener(v -> removeOverlay());
        title.addView(close);
        card.addView(title);

        TextView body = text(s.message, expanded ? 15 : 13, EluaStyle.TEXT, expanded);
        body.setMaxLines(expanded ? 8 : 2);
        body.setEllipsize(android.text.TextUtils.TruncateAt.END);
        body.setPadding(0, dp(2), 0, dp(13));
        card.addView(body);

        if (!expanded) {
            Button open = EluaStyle.button(this, "Leggi il suggerimento   ↗", true);
            open.setOnClickListener(v -> showEluaOverlay(s, excerpt, origin, true));
            card.addView(open);
        } else {
            TextView disclosure = text("Perché appare? Parole del tema «" + s.category +
                "» in un'app autorizzata. Analisi locale, non un'AI generativa.", 11,
                EluaStyle.SUBTEXT, false);
            card.addView(disclosure);
            card.addView(EluaStyle.gap(this, 12));
            LinearLayout first = new LinearLayout(this);
            first.setGravity(Gravity.CENTER_VERTICAL);
            Button save = EluaStyle.button(this, "Salva idea", false);
            Button learn = EluaStyle.button(this, "Approfondisci", true);
            first.addView(save, weighted());
            first.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
            first.addView(learn, weighted());
            card.addView(first);
            card.addView(EluaStyle.gap(this, 9));
            LinearLayout second = new LinearLayout(this);
            Button useful = EluaStyle.button(this, "Utile", false);
            Button notRelevant = EluaStyle.button(this, "Non interessa", false);
            second.addView(useful, weighted());
            second.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
            second.addView(notRelevant, weighted());
            card.addView(second);

            save.setOnClickListener(v -> {
                try { if (store != null) store.saveSuggestion(s, origin); }
                catch (RuntimeException ignored) { /* fail closed: never plain text */ }
                removeOverlay();
            });
            learn.setOnClickListener(v -> {
                removeOverlay();
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra(MainActivity.DRAFT, s.prompt +
                    "\n\nEstratto visibile (controlla prima di condividere):\n" + excerpt);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            });
            useful.setOnClickListener(v -> {
                safeFeedback(s.category, "useful"); removeOverlay();
            });
            notRelevant.setOnClickListener(v -> {
                safeFeedback(s.category, "not_relevant"); removeOverlay();
            });
        }
        int deviceWidth = getResources().getDisplayMetrics().widthPixels;
        int width = Math.min(dp(355), Math.max(dp(240), deviceWidth - dp(24)));
        WindowManager.LayoutParams params = overlayParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, false);
        // User can reposition the compact card; no taps or gestures are sent to the observed app.
        final float[] initial = {0f, 0f};
        final int[] offset = {params.y};
        title.setOnTouchListener((view, motion) -> {
            switch (motion.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    initial[0] = motion.getRawX();
                    initial[1] = motion.getRawY();
                    offset[0] = params.y;
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    int deviceHeight = getResources().getDisplayMetrics().heightPixels;
                    int move = (int)(motion.getRawY() - initial[1]);
                    params.y = Math.max(dp(12), Math.min(deviceHeight - dp(260), offset[0] + move));
                    if (overlay == card && wm != null) {
                        try { wm.updateViewLayout(card, params); }
                        catch (RuntimeException ignored) { }
                    }
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                    return true;
                default: return false;
            }
        });
        try {
            wm.addView(card, params);
            overlay = card;
        } catch (RuntimeException fail) {
            overlay = null;
            return;
        }
        dismissTask = this::removeOverlay;
        main.postDelayed(dismissTask, expanded ? 24_000L : 13_000L);
    }

    private void safeFeedback(String category, String kind) {
        try { if (store != null) store.feedback(category, kind); }
        catch (RuntimeException ignored) { }
    }

    private void removeOverlay() {
        if (dismissTask != null) {
            main.removeCallbacks(dismissTask);
            dismissTask = null;
        }
        if (wm != null && overlay != null) {
            try { wm.removeViewImmediate(overlay); }
            catch (IllegalArgumentException ignored) { }
            overlay = null;
        }
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(11);
        b.setMinHeight(dp(42));
        return b;
    }
    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f);
    }
    @Override public void onConfigurationChanged(android.content.res.Configuration config) {
        super.onConfigurationChanged(config);
        // Folding or rotation invalidates the previous cutout anchor; dismiss until next insight.
        removeOverlay();
    }
    @Override public void onInterrupt() { removeOverlay(); }
    @Override public void onDestroy() {
        if (connected == this) connected = null;
        removeOverlay();
        super.onDestroy();
    }
    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + .5f);
    }
}
