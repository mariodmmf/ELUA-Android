package it.spunto.companion;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.SeekBar;
import java.util.Calendar;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Comparator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Adaptive native design layer: 2026 editorial utility UI, opt-in observation,
 * user-first safety gates. No external SDK, no Internet permission.
 */
public final class MainActivity extends Activity {
    static final String PREFS = "spunto_private";
    static final String ACTIVE = "enabled";
    static final String CONSENT = "accessibility_disclosure_accepted_v1";
    static final String DRAFT = "review_draft";
    static final String HALO_MODE = "eluahalo_optin_v1";
    static final LinkedHashMap<String, String> APPS = new LinkedHashMap<>();
    static {
        // No browser, messaging, banking, email or password manager in this build.
        APPS.put("com.instagram.android", "Instagram");
        APPS.put("com.reddit.frontpage", "Reddit");
        APPS.put("com.zhiliaoapp.musically", "TikTok");
        APPS.put("com.google.android.youtube", "YouTube");
    }

    private InsightStore store;
    private SharedPreferences prefs;
    private LinearLayout content;
    private TextView serviceStatus;
    private int tab = 0;
    private boolean wide;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new InsightStore(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (state != null) tab = state.getInt("tab", 0);
        render();
        receiveDraft(getIntent());
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        state.putInt("tab", tab);
        super.onSaveInstanceState(state);
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        receiveDraft(intent);
    }
    @Override protected void onResume() {
        super.onResume();
        CompanionAccessibilityService.dismissFromSettings();
        refreshStatus();
    }
    private int d(float n) { return EluaStyle.dp(this, n); }
    private TextView text(String s, float size, int color, boolean bold) {
        return EluaStyle.text(this, s, size, color, bold);
    }
    private View gap(int n) { return EluaStyle.gap(this, n); }
    private Button button(String s, boolean primary) { return EluaStyle.button(this, s, primary); }

    private boolean accessibilityEnabled() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        ComponentName component = new ComponentName(this, CompanionAccessibilityService.class);
        List<AccessibilityServiceInfo> enabled =
            manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : enabled) {
            if (component.equals(ComponentName.unflattenFromString(info.getId()))) return true;
        }
        return false;
    }
    private boolean observing() {
        return prefs.getBoolean(CONSENT, false) && prefs.getBoolean(ACTIVE, false) && accessibilityEnabled();
    }
    private void refreshStatus() {
        if (serviceStatus != null)
            serviceStatus.setText(accessibilityEnabled() ? "Servizio Android autorizzato" : "Servizio Android non autorizzato");
    }
    private int allowedCount() {
        int count = 0;
        for (String key : APPS.keySet()) if (prefs.getBoolean("allow:" + key, false)) count++;
        return count;
    }
    private int memoryCount() {
        try { return store.getNotes().length(); }
        catch (RuntimeException error) { return -1; }
    }
    private void render() {
        serviceStatus = null;
        // User-written memories and commitments are hidden from screenshots / recent-app previews.
        if (tab == 2) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        wide = getResources().getConfiguration().screenWidthDp >= 610;
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        shell.setBackgroundColor(EluaStyle.BG);
        setContentView(shell);
        // Android 15+ uses edge-to-edge by default. Protect actionable content from
        // display cutouts, gesture bar and system status bar on both V5 panels.
        shell.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        shell.requestApplyInsets();
        if (wide) {
            shell.addView(sidebar(), new LinearLayout.LayoutParams(d(235), -1));
            View line = new View(this);
            line.setBackgroundColor(EluaStyle.BORDER);
            shell.addView(line, new LinearLayout.LayoutParams(d(1), -1));
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        shell.addView(scroll, new LinearLayout.LayoutParams(wide ? 0 : -1, wide ? -1 : 0, wide ? 1f : 1f));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(d(wide ? 36 : 21), d(26), d(wide ? 36 : 21), d(40));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));

        if (!wide) {
            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView wordmark = EluaStyle.wordmark(this, 28);
            top.addView(wordmark);
            View spacer = new View(this);
            top.addView(spacer, new LinearLayout.LayoutParams(0, d(1), 1f));
            top.addView(statusPill());
            content.addView(top);
            content.addView(gap(30));
        }
        if (tab == 0) buildHome();
        else if (tab == 1) buildRadar();
        else if (tab == 2) buildMemory();
        else if (tab == 3) buildLaboratory();
        else if (tab == 4) buildControl();
        else buildAbout();
        content.addView(gap(28));
        TextView foot = text("ELUA  ·  v0.10 HALO  /  Locale · Nessuna AI generativa", 10, EluaStyle.FAINT, true);
        foot.setLetterSpacing(.07f);
        content.addView(foot);
        if (!wide) shell.addView(bottomBar());
        refreshStatus();
    }
    private TextView statusPill() {
        boolean active = observing();
        TextView pill = text(active ? "●  Attivo" : "●  In pausa", 12,
            active ? EluaStyle.MINT : EluaStyle.AMBER, true);
        pill.setPadding(d(12), d(10), d(12), d(10));
        pill.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE, EluaStyle.BORDER, 30));
        pill.setOnClickListener(v -> { tab = 4; render(); });
        pill.setContentDescription("Stato osservazione: " + (active ? "attiva" : "in pausa") + ". Apri il controllo");
        pill.setMinHeight(d(48));
        pill.setGravity(Gravity.CENTER_VERTICAL);
        return pill;
    }
    private LinearLayout sidebar() {
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setPadding(d(18), d(30), d(18), d(22));
        TextView brand = EluaStyle.wordmark(this, 30);
        side.addView(brand);
        side.addView(gap(8));
        side.addView(EluaStyle.kicker(this, "INTELLIGENZA DISCRETA", EluaStyle.FAINT));
        side.addView(gap(45));
        String[] names = {"⌂   Il tuo spazio", "◎   Radar", "◷   Memoria", "◇   Laboratorio", "◫   Controllo"};
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            TextView item = text(names[i], 15, i == tab ? EluaStyle.TEXT : EluaStyle.SUBTEXT, i == tab);
            item.setMinHeight(d(56));
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(d(16), 0, d(10), 0);
            if (i == tab) item.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE_2, Color.TRANSPARENT, 16));
            item.setOnClickListener(v -> { tab = index; render(); });
            side.addView(item);
            side.addView(gap(7));
        }
        side.addView(new View(this), new LinearLayout.LayoutParams(1, 0, 1f));
        side.addView(statusPill());
        side.addView(gap(12));
        side.addView(text("Il tuo telefono, le tue scelte.", 12, EluaStyle.SUBTEXT, false));
        return side;
    }
    private LinearLayout bottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(d(9), d(7), d(9), d(10));
        bar.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE, Color.TRANSPARENT, 0));
        String[] icons = {"⌂", "◎", "◷", "◇", "◫"};
        String[] labels = {"Oggi", "Radar", "Memoria", "Prova", "Controllo"};
        for (int i = 0; i < 5; i++) {
            final int index = i;
            LinearLayout slot = new LinearLayout(this);
            slot.setOrientation(LinearLayout.VERTICAL);
            slot.setGravity(Gravity.CENTER);
            slot.setMinimumHeight(d(58));
            TextView symbol = text(icons[i], 23, i == tab ? EluaStyle.MINT : EluaStyle.FAINT, true);
            symbol.setGravity(Gravity.CENTER);
            TextView label = text(labels[i], 11, i == tab ? EluaStyle.TEXT : EluaStyle.SUBTEXT, i == tab);
            label.setGravity(Gravity.CENTER);
            slot.addView(symbol);
            slot.addView(label);
            slot.setContentDescription("Apri " + labels[i]);
            if (i == tab) slot.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE_2, Color.TRANSPARENT, 17));
            slot.setOnClickListener(v -> { tab = index; render(); });
            bar.addView(slot, new LinearLayout.LayoutParams(0, d(60), 1f));
        }
        return bar;
    }
    private void heading(String kicker, String headline, String subtitle) {
        content.addView(EluaStyle.kicker(this, kicker, EluaStyle.MINT));
        content.addView(gap(10));
        TextView title = text(headline, wide ? 37 : 32, EluaStyle.TEXT, true);
        title.setLineSpacing(d(2), .98f);
        content.addView(title);
        content.addView(gap(10));
        content.addView(text(subtitle, 14, EluaStyle.SUBTEXT, false));
        content.addView(gap(24));
    }
    private void buildHome() {
        heading("PRESENZA, NON RUMORE", "Un po' più avanti.\nOgni giorno.",
            "Il tuo spazio per connessioni, ricordi e decisioni. Sempre sotto il tuo controllo.");
        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(EluaStyle.gradient(this, Color.rgb(39, 67, 77), Color.rgb(26, 39, 53), 28));
        hero.setMinimumHeight(d(195));
        LinearLayout body = new LinearLayout(this);
        body.setPadding(d(22), d(23), d(22), d(21));
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(EluaStyle.kicker(this, "ELUA  ·  IL TUO ASSISTENTE", EluaStyle.MINT));
        body.addView(gap(11));
        body.addView(text(observing() ? "Attento a ciò che conta." : "Quando vuoi, ci sono.", 25, EluaStyle.TEXT, true));
        body.addView(gap(8));
        body.addView(text(observing() ?
            "Osservazione attiva soltanto nelle app che hai scelto." :
            "L'osservazione è sospesa. Decidi tu quando attivarla.", 13, Color.rgb(205, 226, 224), false));
        body.addView(gap(16));
        Button action = button(observing() ? "Gestisci osservazione  ›" : "Configura con calma  ›", true);
        action.setOnClickListener(v -> { tab = 4; render(); });
        body.addView(action);
        hero.addView(body, new FrameLayout.LayoutParams(-1, -2));
        content.addView(hero);
        content.addView(gap(17));
        if (wide) {
            LinearLayout duo = new LinearLayout(this);
            duo.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout first = summaryCard("MEMORIA", "" + Math.max(memoryCount(),0), "note salvate");
            LinearLayout second = summaryCard("APP AUTORIZZATE", "" + allowedCount(), "su " + APPS.size() + " disponibili");
            duo.addView(first, new LinearLayout.LayoutParams(0, -2, 1f));
            duo.addView(new View(this), new LinearLayout.LayoutParams(d(12), 1));
            duo.addView(second, new LinearLayout.LayoutParams(0, -2, 1f));
            content.addView(duo);
        } else {
            LinearLayout duo = new LinearLayout(this);
            duo.setOrientation(LinearLayout.HORIZONTAL);
            duo.addView(summaryCard("MEMORIA", "" + Math.max(memoryCount(),0), "note salvate"),
                new LinearLayout.LayoutParams(0, -2, 1f));
            duo.addView(new View(this), new LinearLayout.LayoutParams(d(10), 1));
            duo.addView(summaryCard("APP", "" + allowedCount(), "autorizzate"),
                new LinearLayout.LayoutParams(0, -2, 1f));
            content.addView(duo);
        }
        content.addView(gap(18));
        addHomeActionStrip();
        content.addView(gap(23));
        addHomeCommitments();
        content.addView(gap(25));
        content.addView(EluaStyle.kicker(this, "UN'ANTEPRIMA DI COME PARLERÀ", EluaStyle.FAINT));
        content.addView(gap(12));
        LinearLayout insight = EluaStyle.card(this, 20);
        insight.addView(text("ELUA  ·  Un possibile suggerimento", 14, EluaStyle.MINT, true));
        insight.addView(gap(9));
        insight.addView(text("Questa tecnica fotografica potrebbe funzionare anche con due flash.", 19, EluaStyle.TEXT, true));
        insight.addView(gap(9));
        insight.addView(text("Esempio illustrativo · Non deriva da un'osservazione reale.", 12, EluaStyle.SUBTEXT, false));
        insight.addView(gap(15));
        Button demo = button("Prova il flusso di approfondimento  ↗", false);
        demo.setOnClickListener(v -> previewDraft(
            "Analizza questa tecnica fotografica per uno shooting con uno o due flash.\n\n" +
            "[Demo illustrativa: schema luce con softbox laterale]"));
        insight.addView(demo);
        content.addView(insight);
        content.addView(gap(15));
        LinearLayout note = EluaStyle.card(this, 18);
        note.addView(text("La priorità è la fiducia.", 17, EluaStyle.TEXT, true));
        note.addView(gap(6));
        note.addView(text("Questa versione non cerca sul web e non usa un modello AI. Nessun testo letto dalle app viene salvato. Ogni condivisione richiede la tua scelta.", 13, EluaStyle.SUBTEXT, false));
        content.addView(note);
    }
    private LinearLayout summaryCard(String kicker, String number, String detail) {
        LinearLayout card = EluaStyle.card(this, 17);
        card.addView(EluaStyle.kicker(this, kicker, EluaStyle.FAINT));
        card.addView(gap(7));
        card.addView(text(number, 29, EluaStyle.TEXT, true));
        card.addView(gap(3));
        card.addView(text(detail, 12, EluaStyle.SUBTEXT, false));
        card.setMinimumHeight(d(125));
        return card;
    }
    private void buildMemory() {
        heading("RICORDA SOLO CIÒ CHE SCEGLI", "Quello che conta\nresta con te.",
            "Le tue idee e i suggerimenti salvati restano cifrati sul dispositivo.");
        LinearLayout action = EluaStyle.card(this, 19);
        action.addView(text("Un pensiero da conservare?", 19, EluaStyle.TEXT, true));
        action.addView(gap(8));
        action.addView(text("Non analizziamo le tue conversazioni per costruire questa memoria. Aggiungi qui solo ciò che vuoi ricordare.", 13, EluaStyle.SUBTEXT, false));
        action.addView(gap(15));
        Button add = button("＋  Aggiungi un ricordo", true);
        add.setOnClickListener(v -> newNote());
        action.addView(add);
        content.addView(action);
        content.addView(gap(27));
        content.addView(EluaStyle.kicker(this, "IL TUO ARCHIVIO", EluaStyle.MINT));
        content.addView(gap(9));
        EditText find = new EditText(this);
        find.setSingleLine(true);
        find.setTextSize(14);
        find.setTextColor(EluaStyle.TEXT);
        find.setHintTextColor(EluaStyle.SUBTEXT);
        find.setHint("Cerca tra le note salvate…");
        find.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE_2, EluaStyle.BORDER, 15));
        find.setPadding(d(14), d(12), d(14), d(12));
        content.addView(find);
        content.addView(gap(13));
        LinearLayout notesArea = new LinearLayout(this);
        notesArea.setOrientation(LinearLayout.VERTICAL);
        content.addView(notesArea);
        addNotesToUI(notesArea, "");
        find.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                notesArea.removeAllViews();
                addNotesToUI(notesArea, s.toString().toLowerCase(Locale.ITALIAN));
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        content.addView(gap(17));
        content.addView(EluaStyle.kicker(this, "IMPEGNI INSERITI DA TE", EluaStyle.MINT));
        content.addView(gap(11));
        Button newCommit = button("＋  Aggiungi un impegno con data", true);
        newCommit.setOnClickListener(v -> newCommitment());
        content.addView(newCommit);
        content.addView(gap(13));
        addCommitmentsToUI(false);
        content.addView(gap(20));
        Button clear = button("Elimina tutta la memoria, impegni e feedback", false);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Cancellare tutta la memoria?")
            .setMessage("Saranno eliminati note, impegni, categorie d'interesse e feedback. L'operazione non si può annullare.")
            .setPositiveButton("Elimina", (dlg, w) -> {
                try { store.clear(); render(); }
                catch (RuntimeException e) { showStorageError(e); }
            }).setNegativeButton("Annulla", null).show());
        content.addView(clear);
    }
    private void addNotesToUI(LinearLayout root, String query) {
        try {
            JSONArray notes = store.getNotes();
            if (notes.length() == 0) {
                LinearLayout empty = EluaStyle.card(this, 23);
                empty.addView(text("◌", 35, EluaStyle.MINT, true));
                empty.addView(gap(7));
                empty.addView(text("Qui c'è ancora spazio.", 19, EluaStyle.TEXT, true));
                empty.addView(gap(6));
                empty.addView(text("Non hai note salvate. Il primo ricordo lo scegli tu.", 13, EluaStyle.SUBTEXT, false));
                root.addView(empty);
                return;
            }
            int matches = 0;
            for (int i = notes.length() - 1; i >= 0; i--) {
                JSONObject item = notes.optJSONObject(i);
                if (item == null || !item.optString("text", "").toLowerCase(Locale.ITALIAN).contains(query)) continue;
                if (matches++ >= 40) break;
                final int index = i;
                LinearLayout row = EluaStyle.card(this, 17);
                row.addView(EluaStyle.kicker(this,
                    item.optString("category", "NOTA") + "   ·   " +
                    DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(item.optLong("when", 0))), EluaStyle.MINT));
                row.addView(gap(9));
                row.addView(text(item.optString("text", ""), 15, EluaStyle.TEXT, false));
                row.addView(gap(12));
                Button remove = button("Elimina questa nota", false);
                remove.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Eliminare la nota?")
                    .setPositiveButton("Elimina", (dlg, w) -> {
                        try { store.deleteNoteAt(index); render(); }
                        catch (RuntimeException e) { showStorageError(e); }
                    }).setNegativeButton("Annulla", null).show());
                row.addView(remove);
                root.addView(row);
                root.addView(gap(10));
            }
            if (matches == 0) root.addView(text("Nessuna nota corrisponde alla ricerca.", 13, EluaStyle.SUBTEXT, false));
        } catch (RuntimeException error) {
            root.addView(text("Memoria cifrata non disponibile. Non verrà effettuato nessun salvataggio in chiaro.", 14, EluaStyle.DANGER, true));
        }
    }
    private void buildControl() {
        heading("TUTTO SOTTO IL TUO CONTROLLO", "Scegli quanto\nessere presente.",
            "Decidi se, quando e dove Elua può osservare i testi accessibili.");
        LinearLayout statusCard = EluaStyle.card(this, 20);
        statusCard.addView(EluaStyle.kicker(this, "STATO DELL'OSSERVAZIONE", EluaStyle.FAINT));
        statusCard.addView(gap(8));
        statusCard.addView(text(observing() ? "●  Attiva" : "●  In pausa", 24,
            observing() ? EluaStyle.MINT : EluaStyle.AMBER, true));
        statusCard.addView(gap(8));
        serviceStatus = text("Verifica autorizzazione…", 13, EluaStyle.SUBTEXT, false);
        statusCard.addView(serviceStatus);
        statusCard.addView(gap(14));
        Button stop = button("■  Ferma subito Elua", false);
        stop.setTextColor(EluaStyle.DANGER);
        stop.setOnClickListener(v -> {
            prefs.edit().putBoolean(ACTIVE, false).apply();
            CompanionAccessibilityService.dismissFromSettings();
            Toast.makeText(this, "Osservazione sospesa.", Toast.LENGTH_SHORT).show();
            render();
        });
        statusCard.addView(stop);
        content.addView(statusCard);
        content.addView(gap(16));

        LinearLayout consentCard = EluaStyle.card(this, 20);
        consentCard.addView(text("Prima di tutto, il consenso", 19, EluaStyle.TEXT, true));
        consentCard.addView(gap(9));
        consentCard.addView(text(
            "Con il servizio Accessibilità Elua può leggere alcuni TESTI VISIBILI NON EDITABILI soltanto nelle app consentite qui sotto. " +
            "Li analizza localmente per mostrare spunti su fotografia, pubblicità, AI e gaming. " +
            "Non archivia testi dello schermo, non fa screenshot, non ascolta, non usa Internet. " +
            "Memorizza solo note scelte da te, feedback e categorie anonime associate al nome dell'app. " +
            "Puoi sospenderlo o revocare il consenso in ogni momento.", 13, EluaStyle.SUBTEXT, false));
        consentCard.addView(gap(15));
        CheckBox disclosure = new CheckBox(this);
        disclosure.setText("Ho letto e accetto l'uso di Accessibilità descritto sopra");
        disclosure.setTextColor(EluaStyle.TEXT);
        disclosure.setTextSize(14);
        disclosure.setMinHeight(d(56));
        disclosure.setButtonTintList(EluaStyle.tint(EluaStyle.MINT));
        disclosure.setChecked(prefs.getBoolean(CONSENT, false));
        disclosure.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean(CONSENT, checked).apply();
            if (!checked) {
                prefs.edit().putBoolean(ACTIVE, false).apply();
                CompanionAccessibilityService.dismissFromSettings();
            }
            render();
        });
        consentCard.addView(disclosure);
        Button settings = button("Apri Accessibilità di Android  ↗", false);
        settings.setOnClickListener(v -> {
            if (!prefs.getBoolean(CONSENT, false)) {
                Toast.makeText(this, "Prima leggi e accetta l'informativa.", Toast.LENGTH_LONG).show();
                return;
            }
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
        consentCard.addView(settings);
        consentCard.addView(gap(13));
        Switch active = new Switch(this);
        active.setText("Osservazione e suggerimenti");
        active.setTextColor(EluaStyle.TEXT);
        active.setTextSize(15);
        active.setMinimumHeight(d(56));
        active.setThumbTintList(EluaStyle.tint(EluaStyle.MINT));
        active.setChecked(prefs.getBoolean(ACTIVE, false));
        active.setOnCheckedChangeListener((v, enabled) -> {
            if (enabled && !prefs.getBoolean(CONSENT, false)) {
                Toast.makeText(this, "Prima accetta l'informativa.", Toast.LENGTH_SHORT).show();
                active.setChecked(false);
                return;
            }
            prefs.edit().putBoolean(ACTIVE, enabled).apply();
            if (!enabled) CompanionAccessibilityService.dismissFromSettings();
            render();
        });
        consentCard.addView(active);
        content.addView(consentCard);
        content.addView(gap(24));
        content.addView(EluaStyle.kicker(this, "APP CHE PUOI AUTORIZZARE", EluaStyle.MINT));
        content.addView(gap(9));
        content.addView(text("Nessuna app è abilitata automaticamente. Non sono incluse chat, browser, email, banche o password manager.", 13, EluaStyle.SUBTEXT, false));
        content.addView(gap(13));
        LinearLayout list = EluaStyle.card(this, 12);
        for (Map.Entry<String, String> entry : APPS.entrySet()) {
            String pkg = entry.getKey();
            Switch item = new Switch(this);
            item.setText(entry.getValue());
            item.setTextColor(EluaStyle.TEXT);
            item.setTextSize(16);
            item.setPadding(d(9), d(5), d(9), d(5));
            item.setMinHeight(d(59));
            item.setThumbTintList(EluaStyle.tint(EluaStyle.MINT));
            item.setChecked(prefs.getBoolean("allow:" + pkg, false));
            item.setOnCheckedChangeListener((v, enabled) -> {
                if (enabled && !prefs.getBoolean(CONSENT, false)) {
                    Toast.makeText(this, "Prima accetta l'informativa.", Toast.LENGTH_SHORT).show();
                    item.setChecked(false);
                    return;
                }
                prefs.edit().putBoolean("allow:" + pkg, enabled).apply();
                if (!enabled) CompanionAccessibilityService.dismissFromSettings();
            });
            list.addView(item);
        }
        content.addView(list);
        content.addView(gap(20));
        addHaloSettings();
        content.addView(gap(20));
        addTopicControls();
        content.addView(gap(18));
        Button moreInfo = button("Cosa Elua può e non può fare  ›", false);
        moreInfo.setOnClickListener(v -> { tab = 5; render(); });
        content.addView(moreInfo);
        content.addView(gap(16));
        content.addView(text("Nota: i filtri per i contenuti sensibili sono precauzionali, non infallibili. Non autorizzare app contenenti informazioni private.", 13, EluaStyle.SUBTEXT, false));
    }
    private void addHomeActionStrip() {
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        Button radar = button("◎  Apri Radar", false);
        Button note = button("＋  Nuovo ricordo", false);
        radar.setOnClickListener(v -> { tab = 1; render(); });
        note.setOnClickListener(v -> newNote());
        strip.addView(radar, new LinearLayout.LayoutParams(0, -2, 1));
        strip.addView(new View(this), new LinearLayout.LayoutParams(d(9), 1));
        strip.addView(note, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(strip);
    }

    private void addHomeCommitments() {
        try {
            JSONArray tasks = store.getCommitments();
            int open = 0, due = 0;
            long now = System.currentTimeMillis();
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject task = tasks.optJSONObject(i);
                if (task == null || task.optBoolean("done", false)) continue;
                open++;
                if (EluaPolicy.dueSoon(task.optLong("due", 0), now)) due++;
            }
            LinearLayout c = EluaStyle.card(this, 19);
            c.addView(EluaStyle.kicker(this, "IMPEGNI CHE HAI SALVATO", EluaStyle.MINT));
            c.addView(gap(9));
            c.addView(text(open == 0 ? "Niente in sospeso." :
                open + " in sospeso" + (due > 0 ? " · " + due + " in scadenza" : ""), 20, EluaStyle.TEXT, true));
            c.addView(gap(8));
            c.addView(text(open == 0 ? "Aggiungi una scadenza quando vuoi. Nessun evento viene creato nel calendario." :
                "Sono impegni inseriti e confermati da te, non deduzioni dalle chat.", 12, EluaStyle.SUBTEXT, false));
            c.addView(gap(12));
            Button openMemory = button(open == 0 ? "Aggiungi un impegno  ›" : "Rivedi i tuoi impegni  ›", false);
            openMemory.setOnClickListener(v -> { tab = 2; render(); });
            c.addView(openMemory);
            content.addView(c);
        } catch (RuntimeException error) {
            content.addView(text("Impegni non disponibili: archivio cifrato non accessibile.", 12, EluaStyle.DANGER, false));
        }
    }

    private void buildRadar() {
        heading("RADAR PERSONALE", "Le connessioni\nche emergono.",
            "Tendenze anonime delle app autorizzate, senza conservare messaggi, post o schermate.");
        LinearLayout hero = EluaStyle.card(this, 21);
        hero.addView(EluaStyle.kicker(this, "ATTENZIONE SELETTIVA", EluaStyle.MINT));
        hero.addView(gap(9));
        hero.addView(text("Non ogni scroll deve diventare un suggerimento.", 21, EluaStyle.TEXT, true));
        hero.addView(gap(8));
        hero.addView(text("Un argomento viene annotato solo come categoria, app e data approssimativa. Il testo originale non viene archiviato.", 13, EluaStyle.SUBTEXT, false));
        content.addView(hero);
        content.addView(gap(24));
        content.addView(EluaStyle.kicker(this, "TEMI RICONOSCIUTI NEGLI ULTIMI 14 GIORNI", EluaStyle.FAINT));
        content.addView(gap(12));
        try {
            JSONArray radar = store.getRadar();
            java.util.List<JSONObject> entries = new java.util.ArrayList<>();
            for (int i = 0; i < radar.length(); i++) {
                JSONObject item = radar.optJSONObject(i);
                if (item != null) entries.add(item);
            }
            entries.sort((a,b) -> Long.compare(b.optLong("last", 0), a.optLong("last", 0)));
            if (entries.isEmpty()) {
                LinearLayout empty = EluaStyle.card(this, 22);
                empty.addView(text("Ancora nessuna ricorrenza.", 19, EluaStyle.TEXT, true));
                empty.addView(gap(8));
                empty.addView(text("Il Radar si popolerà soltanto se attiverai il servizio e le app consentite. Puoi intanto provare le regole nel Laboratorio.", 13, EluaStyle.SUBTEXT, false));
                content.addView(empty);
            }
            for (JSONObject item : entries) {
                final String category = item.optString("category", "Tema");
                final int score = store.score(category);
                LinearLayout card = EluaStyle.card(this, 18);
                card.addView(EluaStyle.kicker(this, "SEGNALE LOCALE  ·  " + category.toUpperCase(Locale.ITALIAN), EluaStyle.MINT));
                card.addView(gap(9));
                int apps = item.optInt("apps", 0);
                card.addView(text(apps >= 2 ? "Un tema ricorrente in " + apps + " app" :
                    "Tema rilevato in una app", 18, EluaStyle.TEXT, true));
                card.addView(gap(8));
                card.addView(text("Ultimo segnale: " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                    .format(new Date(item.optLong("last", 0))) +
                    " · Feedback: " + (score > 0 ? "positivo" : (score < 0 ? "meno pertinente" : "da conoscere")),
                    12, EluaStyle.SUBTEXT, false));
                card.addView(gap(12));
                Button off = button(prefs.getBoolean("topic:" + category, true) ? "Nascondi questo tema" : "Riattiva questo tema", false);
                off.setOnClickListener(v -> { prefs.edit().putBoolean("topic:" + category,
                    !prefs.getBoolean("topic:" + category, true)).apply(); render(); });
                card.addView(off);
                content.addView(card);
                content.addView(gap(10));
            }
        } catch (RuntimeException error) {
            content.addView(text("Non posso mostrare il Radar: memoria cifrata non disponibile.", 13, EluaStyle.DANGER, true));
        }
        content.addView(gap(20));
        Button test = button("◇  Vai al Laboratorio", true);
        test.setOnClickListener(v -> { tab = 3; render(); });
        content.addView(test);
    }

    private void buildLaboratory() {
        heading("LABORATORIO PRIVATO", "Prova un'idea.\nSenza rischi.",
            "Incolla un testo scelto da te: ELUA lo valuta in locale, senza salvarlo né inviarlo online.");
        LinearLayout c = EluaStyle.card(this, 21);
        c.addView(EluaStyle.kicker(this, "TEST DEL MOTORE LOCALE", EluaStyle.MINT));
        c.addView(gap(9));
        c.addView(text("Ti mostra cosa riconosce davvero, perché lo riconosce e dove potrebbe sbagliare.", 14, EluaStyle.TEXT, false));
        c.addView(gap(13));
        EditText sample = new EditText(this);
        sample.setTextColor(EluaStyle.TEXT);
        sample.setHintTextColor(EluaStyle.SUBTEXT);
        sample.setHint("Per esempio: uno schema luce con softbox laterale e due flash…");
        sample.setTextSize(14);
        sample.setMinLines(4);
        sample.setMaxLines(7);
        sample.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        sample.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE_2, EluaStyle.BORDER, 14));
        sample.setPadding(d(15), d(15), d(15), d(15));
        c.addView(sample);
        c.addView(gap(12));
        Button run = button("Analizza solo sul telefono  ›", true);
        run.setOnClickListener(v -> {
            String value = sample.getText().toString().trim();
            if (value.length() < 20) { Toast.makeText(this, "Servono almeno 20 caratteri.", Toast.LENGTH_SHORT).show(); return; }
            if (value.length() > 2200) { Toast.makeText(this, "Massimo 2200 caratteri.", Toast.LENGTH_SHORT).show(); return; }
            if (LocalRules.isSensitive(value)) {
                new AlertDialog.Builder(this).setTitle("Contenuto sensibile")
                    .setMessage("La valutazione è stata bloccata dal filtro locale. Nessun testo è stato salvato.")
                    .setPositiveButton("OK", null).show();
                return;
            }
            LocalRules.Suggestion found = LocalRules.analyze(value);
            if (found == null) {
                new AlertDialog.Builder(this).setTitle("Nessun segnale sufficiente")
                    .setMessage("Le regole attuali non riconoscono un tema pertinente. Non è una valutazione della qualità del contenuto: serve ancora un modello AI.")
                    .setPositiveButton("Capito", null).show();
                return;
            }
            new AlertDialog.Builder(this).setTitle("Riconosciuto: " + found.category)
                .setMessage(found.message + "\n\nMotivo: corrispondenza con parole o espressioni del dizionario locale. Non è una conclusione di un modello AI.\n\nIl tuo testo non verrà memorizzato.")
                .setPositiveButton("Salva il suggerimento", (dialog, which) -> {
                    try { store.saveSuggestion(found, "Laboratorio manuale"); Toast.makeText(this, "Suggerimento salvato.", Toast.LENGTH_SHORT).show(); }
                    catch (RuntimeException e) { showStorageError(e); }
                })
                .setNeutralButton("Cerca online", (dialog, which) -> {
                    String query = "approfondimento " + found.category + " 2026";
                    new AlertDialog.Builder(this).setTitle("Aprire una ricerca nel browser?")
                        .setMessage("ELUA aprirà una ricerca pubblica per «" + query + "». Il tuo testo originale NON verrà inviato al browser.")
                        .setPositiveButton("Apri ricerca", (dlg, w) -> {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))));
                        }).setNegativeButton("Annulla", null).show();
                })
                .setNegativeButton("Chiudi", null).show();
        });
        c.addView(run);
        content.addView(c);
        content.addView(gap(17));
        detailCard("PRIVACY PRIMA", "Nessun testo del laboratorio è scritto nella memoria. Se salvi, ELUA conserva soltanto la frase predefinita del suggerimento, non il tuo testo originale.", EluaStyle.MINT);
        detailCard("FUNZIONE REALE", "Funziona anche a servizio Accessibilità disattivato. Non richiede Internet, API a pagamento o account esterni.", EluaStyle.AMBER);
    }

    private void addHaloSettings() {
        LinearLayout card = EluaStyle.card(this, 19);
        card.addView(EluaStyle.kicker(this, "PRESENZA CONTESTUALE", EluaStyle.MINT));
        card.addView(gap(9));
        card.addView(text("ELUA Halo", 22, EluaStyle.TEXT, true));
        card.addView(gap(7));
        card.addView(text("Quando nasce un suggerimento nelle app consentite, mostra una piccola capsula sotto la fotocamera invece della scheda classica. Si espande solo se la tocchi.",
            13, EluaStyle.SUBTEXT, false));
        card.addView(gap(12));
        Switch switcher = new Switch(this);
        switcher.setText("Attiva Halo vicino al notch");
        switcher.setTextColor(EluaStyle.TEXT);
        switcher.setTextSize(14);
        switcher.setMinHeight(d(54));
        switcher.setThumbTintList(EluaStyle.tint(EluaStyle.MINT));
        switcher.setChecked(prefs.getBoolean(HALO_MODE, false));
        switcher.setOnCheckedChangeListener((v, yes) -> {
            prefs.edit().putBoolean(HALO_MODE, yes).apply();
            CompanionAccessibilityService.dismissFromSettings();
        });
        card.addView(switcher);
        card.addView(gap(8));
        TextView demonstration = text("elua.    ·    FOTOGRAFIA                         ×", 12, EluaStyle.MINT, true);
        demonstration.setPadding(d(13), d(12), d(13), d(12));
        demonstration.setGravity(Gravity.CENTER_VERTICAL);
        demonstration.setBackground(EluaStyle.panel(this, EluaStyle.SURFACE_2, EluaStyle.BORDER, 25));
        demonstration.setContentDescription("Esempio statico della capsula Halo: non osserva il telefono");
        card.addView(demonstration);
        card.addView(gap(10));
        card.addView(text("La capsula non sostituisce Magic Capsule di HONOR, non si sovrappone alla barra di stato e non resta sempre attiva. Se Android impedisce la finestra, nessun permesso aggiuntivo viene richiesto.",
            12, EluaStyle.SUBTEXT, false));
        content.addView(card);
    }

    private void addTopicControls() {
        content.addView(EluaStyle.kicker(this, "QUALI ARGOMENTI ASCOLTARE", EluaStyle.MINT));
        content.addView(gap(7));
        content.addView(text("Spegni qualsiasi categoria. Nessuna scelta modifica altre app.", 13, EluaStyle.SUBTEXT, false));
        content.addView(gap(12));
        LinearLayout topics = EluaStyle.card(this, 12);
        for (String cat : EluaPolicy.TOPICS) {
            Switch sw = new Switch(this);
            sw.setText(cat);
            sw.setTextColor(EluaStyle.TEXT);
            sw.setTextSize(15);
            sw.setMinHeight(d(52));
            sw.setPadding(d(9), d(4), d(9), d(4));
            sw.setThumbTintList(EluaStyle.tint(EluaStyle.MINT));
            sw.setChecked(prefs.getBoolean("topic:" + cat, true));
            sw.setOnCheckedChangeListener((v, checked) -> {
                prefs.edit().putBoolean("topic:" + cat, checked).apply();
                if (!checked) CompanionAccessibilityService.dismissFromSettings();
            });
            topics.addView(sw);
        }
        content.addView(topics);
        content.addView(gap(18));
        content.addView(EluaStyle.kicker(this, "FREQUENZA DEI SUGGERIMENTI", EluaStyle.MINT));
        content.addView(gap(8));
        TextView tempo = text("", 13, EluaStyle.SUBTEXT, false);
        int saved = Math.max(0, Math.min(2, prefs.getInt("intensity", 1)));
        String[] labels = {"Più presente · minimo 1 minuto", "Equilibrata · minimo 3 minuti", "Discreta · minimo 6 minuti"};
        tempo.setText(labels[saved]);
        content.addView(tempo);
        SeekBar bar = new SeekBar(this);
        bar.setMax(2);
        bar.setProgress(saved);
        bar.setProgressTintList(EluaStyle.tint(EluaStyle.MINT));
        bar.setThumbTintList(EluaStyle.tint(EluaStyle.MINT));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int value, boolean user) {
                tempo.setText(labels[Math.max(0, Math.min(2, value))]);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                prefs.edit().putInt("intensity", s.getProgress()).apply();
            }
        });
        content.addView(bar);
        content.addView(gap(10));
        content.addView(text("Il livello modifica solo un intervallo minimo fra popup; non analizza o interpreta la tua concentrazione.", 12, EluaStyle.SUBTEXT, false));
    }

    private void newCommitment() {
        EditText title = new EditText(this);
        title.setTextColor(EluaStyle.TEXT);
        title.setHintTextColor(EluaStyle.SUBTEXT);
        title.setHint("Es. Consegna foto al cliente");
        title.setSingleLine(true);
        title.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(160)});
        long[] date = {0L};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(d(18), d(3), d(18), d(3));
        box.addView(title);
        TextView hint = text("Nessuna data selezionata", 13, EluaStyle.SUBTEXT, false);
        box.addView(gap(10));
        box.addView(hint);
        Button pick = button("Scegli data  ▾", false);
        box.addView(gap(12));
        box.addView(pick);
        pick.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                cal.set(year, month, day, 12, 0, 0);
                cal.set(Calendar.MILLISECOND, 0);
                date[0] = cal.getTimeInMillis();
                hint.setText(DateFormat.getDateInstance(DateFormat.FULL).format(cal.getTime()));
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });
        new AlertDialog.Builder(this).setTitle("Un impegno scelto da te")
            .setView(box)
            .setPositiveButton("Salva impegno", (dlg, which) -> {
                try { store.addCommitment(title.getText().toString(), date[0]); tab = 2; render(); }
                catch (RuntimeException e) { showStorageError(e); }
            }).setNegativeButton("Annulla", null).show();
    }

    private void addCommitmentsToUI(boolean compact) {
        try {
            JSONArray tasks = store.getCommitments();
            if (tasks.length() == 0) {
                content.addView(text("Nessun impegno. Le scadenze non vengono lette dalle chat in questa versione.", 13, EluaStyle.SUBTEXT, false));
                return;
            }
            long now = System.currentTimeMillis();
            int shown = 0;
            for (int i = tasks.length() - 1; i >= 0; i--) {
                JSONObject task = tasks.optJSONObject(i);
                if (task == null) continue;
                if (compact && task.optBoolean("done", false)) continue;
                final int index = i;
                boolean done = task.optBoolean("done", false);
                long date = task.optLong("due", 0);
                LinearLayout line = EluaStyle.card(this, 17);
                line.addView(EluaStyle.kicker(this, done ? "COMPLETATO" :
                    (date == 0 ? "SENZA DATA" : EluaPolicy.dueSoon(date, now) ? "IN SCADENZA" : "DA FARE"),
                    done ? EluaStyle.FAINT : date > 0 && EluaPolicy.dueSoon(date, now) ? EluaStyle.AMBER : EluaStyle.MINT));
                line.addView(gap(8));
                line.addView(text(task.optString("title", ""), 17, done ? EluaStyle.SUBTEXT : EluaStyle.TEXT, !done));
                if (date > 0) {
                    line.addView(gap(6));
                    line.addView(text("Per il " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(date)), 12, EluaStyle.SUBTEXT, false));
                }
                line.addView(gap(11));
                LinearLayout actions = new LinearLayout(this);
                Button mark = button(done ? "Riapri" : "Segna completato", false);
                actions.addView(mark, new LinearLayout.LayoutParams(0, -2, 2));
                actions.addView(new View(this), new LinearLayout.LayoutParams(d(8), 1));
                Button remove = button("Elimina", false);
                actions.addView(remove, new LinearLayout.LayoutParams(0, -2, 1));
                mark.setOnClickListener(v -> {
                    try { store.completeCommitment(index, !done); render(); }
                    catch (RuntimeException e) { showStorageError(e); }
                });
                remove.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Eliminare questo impegno?")
                    .setPositiveButton("Elimina", (dlg,w) -> {
                        try { store.deleteCommitment(index); render(); }
                        catch (RuntimeException e) { showStorageError(e); }
                    }).setNegativeButton("Annulla", null).show());
                line.addView(actions);
                content.addView(line);
                content.addView(gap(10));
                if (++shown >= (compact ? 5 : 50)) break;
            }
        } catch (RuntimeException error) {
            content.addView(text("Archivio impegni non disponibile. Nessun salvataggio in chiaro.", 13, EluaStyle.DANGER, true));
        }
    }

    private void buildAbout() {
        heading("TRASPARENZA RADICALE", "Cosa fa.\nCosa non fa.",
            "Un prototipo utile solo se è onesto sui suoi limiti.");
        detailCard("01   IL PRESENTE", "Riconosce temi selezionati nei testi di quattro app opzionali; Radar e Laboratorio mostrano solo elaborazioni locali. Nessun modello generativo.", EluaStyle.MINT);
        detailCard("02   LA MEMORIA", "Archivio cifrato con note scelte, impegni manuali, feedback e categorie anonime. Non salva mai i testi osservati, foto o messaggi.", EluaStyle.AMBER);
        detailCard("03   IL CONFINE", "Non usa Internet, non ascolta il microfono, non vede foto o video e non legge WhatsApp, Telegram, browser, banche o password.", EluaStyle.MINT);
        detailCard("04   LE AZIONI", "Elua non può cliccare o scrivere in altre app. La condivisione di un testo apre sempre un'anteprima modificabile e richiede una tua scelta.", EluaStyle.AMBER);
        detailCard("05   DOMANI", "I modelli AI, la ricerca web, la comprensione visiva e la personalità evolutiva sono obiettivi futuri, non capacità di questa versione.", EluaStyle.MINT);
        content.addView(gap(9));
        content.addView(text("Design ispirato a sistemi di utilità contemporanei, con gerarchia editoriale, navigazione adattiva e componenti leggibili. Non è affiliato ai prodotti studiati.", 12, EluaStyle.FAINT, false));
    }
    private void detailCard(String header, String paragraph, int color) {
        LinearLayout card = EluaStyle.card(this, 20);
        card.addView(EluaStyle.kicker(this, header, color));
        card.addView(gap(11));
        card.addView(text(paragraph, 15, EluaStyle.TEXT, false));
        content.addView(card);
        content.addView(gap(12));
    }
    private void newNote() {
        EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(7);
        input.setTextColor(EluaStyle.TEXT);
        input.setHintTextColor(EluaStyle.SUBTEXT);
        input.setHint("Un'idea, un progetto, una cosa da ricordare…");
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(d(20), d(3), d(20), 0);
        wrapper.addView(input);
        new AlertDialog.Builder(this).setTitle("Nuovo ricordo scelto da te")
            .setView(wrapper).setPositiveButton("Salva cifrato", (dialog, which) -> {
                try { store.addNote(input.getText().toString()); tab = 1; render(); }
                catch (RuntimeException e) { showStorageError(e); }
            }).setNegativeButton("Annulla", null).show();
    }
    private void receiveDraft(Intent intent) {
        if (intent == null) return;
        String draft = intent.getStringExtra(DRAFT);
        if (draft == null) return;
        intent.removeExtra(DRAFT);
        previewDraft(draft);
    }
    private void previewDraft(String initial) {
        EditText edit = new EditText(this);
        edit.setText(initial);
        edit.setTextColor(EluaStyle.TEXT);
        edit.setTextSize(14);
        edit.setMinLines(4);
        edit.setMaxLines(12);
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(d(18), d(10), d(18), 0);
        wrapper.addView(text("Ogni parola resta sotto il tuo controllo. Nessuna condivisione parte automaticamente.", 13, EluaStyle.SUBTEXT, false));
        wrapper.addView(gap(12));
        wrapper.addView(edit);
        new AlertDialog.Builder(this).setTitle("Controlla prima di condividere")
            .setView(wrapper)
            .setPositiveButton("Condividi…", (dialog, which) -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, edit.getText().toString());
                startActivity(Intent.createChooser(send, "Scegli tu la destinazione"));
            })
            .setNeutralButton("Copia e apri ChatGPT", (dialog, which) -> {
                ClipboardManager clip = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clip != null) clip.setPrimaryClip(ClipData.newPlainText("Elua", edit.getText().toString()));
                Intent target = getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
                if (target != null) startActivity(target);
                else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/")));
            })
            .setNegativeButton("Annulla", null).show();
    }
    private void showStorageError(RuntimeException error) {
        new AlertDialog.Builder(this).setTitle("Memoria non disponibile")
            .setMessage("Operazione annullata. Nessun dato viene salvato in chiaro.\n\n" + error.getMessage())
            .setPositiveButton("OK", null).show();
    }
}
