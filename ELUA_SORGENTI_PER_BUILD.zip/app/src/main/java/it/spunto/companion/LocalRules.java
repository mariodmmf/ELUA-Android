package it.spunto.companion;

import java.util.Locale;
import java.util.regex.Pattern;

/** Local, deterministic matching: NOT a large language model. No network calls. */
final class LocalRules {
    static final class Suggestion {
        final String category;
        final String message;
        final String prompt;
        Suggestion(String category, String message, String prompt) {
            this.category = category;
            this.message = message;
            this.prompt = prompt;
        }
    }

    // Conservative fail-closed detector for obviously sensitive screens.
    // Not guaranteed to detect all private info. Browser content is higher risk.
    private static final Pattern SENSITIVE = Pattern.compile(
        "\\b(password|passcode|otp|iban|swift|cvv|cvc|pin|bonifico|" +
        "saldo disponibile|conto corrente|carta di credito|carta di debito|" +
        "registrazione|password dimenticata|accesso al conto|verifica dell.identità|" +
        "codice temporaneo|security code|password reset|sign in|log in|" +
        "home banking|codice fiscale|identità digitale|autenticazione a due fattori|" +
        "codice di verifica|one.time password|two.factor|credit card|bank account)\\b",
        Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    static boolean isSensitive(String text) {
        return SENSITIVE.matcher(text).find() ||
            Pattern.compile("\\bIT\\d{2}[A-Z0-9]{23}\\b", Pattern.CASE_INSENSITIVE).matcher(text).find();
    }

    static Suggestion analyze(String text) {
        if (text == null || text.length() < 40 || isSensitive(text)) return null;
        String s = text.toLowerCase(Locale.ROOT);
        // Weak local warning: phrasing alone NEVER proves that a page is fraudulent.
        if ((hits(s, "hai vinto", "premio garantito", "account verrà sospeso",
                "offerta scade tra", "verifica subito il tuo account", "congratulazioni hai vinto")
                && hits(s, "clicca", "link", "accedi", "riscatta"))) {
            return new Suggestion("Attenzione digitale",
                "Questo contenuto usa segnali di urgenza o premio: non significa che sia una truffa, ma verifica fonte e indirizzo prima di aprire link.",
                "Valuta i possibili segnali di phishing di questo contenuto senza dare per scontato che sia una truffa.");
        }
        if (hits(s, "softbox", "schema luce", "lightroom", "composizione fotografica",
                "fotografia pubblicitaria", "portrait lighting", "flash photography", "reflector")) {
            return new Suggestion("Fotografia", "Qui potrebbe esserci un suggerimento utile per il tuo prossimo set fotografico.",
                "Analizza questa tecnica fotografica e suggerisci come provarla con uno o due flash in uno shooting pubblicitario.");
        }
        if (hits(s, "meta ads", "google ads", "performance max", "roas", "conversion rate",
                "cost per acquisition", "tiktok ads", "ga4", "attribution")) {
            return new Suggestion("Advertising", "Questo tema potrebbe avere un'applicazione pratica nelle tue campagne.",
                "Valuta il contenuto dal punto di vista di un performance marketer. Cosa testeresti davvero, e con quali KPI?");
        }
        if (hits(s, "openai", "generative ai", "agenti ai", "ai agents", "intelligenza artificiale",
                "multimodal", "claude", "gemini", "midjourney", "sora")) {
            return new Suggestion("AI", "Potrebbe essere un aggiornamento o un'idea da portare in studio.",
                "Spiegami la novità AI in modo concreto e suggerisci un test di 15 minuti per un'agenzia creativa.");
        }
        if (hits(s, "magic v5", "magic9", "magic 9", "honor", "foldable", "magicos",
                "android 17", "smartphone pieghevole")) {
            return new Suggestion("Tecnologia", "Questo potrebbe riguardare il tuo HONOR o il modo in cui lo utilizzi.",
                "Dimmi se questa notizia tecnologica ha conseguenze pratiche per chi usa un HONOR Magic V5.");
        }
        if (hits(s, "viaggio", "weekend fuori", "voli low cost", "itinerario", "city break",
                "travel deal", "destinazioni", "treno notturno")) {
            return new Suggestion("Viaggi", "Potrebbe esserci un'idea per cambiare aria. Vale la pena approfondirla?",
                "Esamina questa idea di viaggio e proponi possibili vantaggi, costi e aspetti da verificare con fonti aggiornate.");
        }
        if (hits(s, "storytelling", "creative brief", "idea creativa", "art direction",
                "campagna creativa", "visual concept", "visual storytelling")) {
            return new Suggestion("Creatività", "Questa idea potrebbe collegarsi a un progetto creativo che hai in mente.",
                "Esplora questa idea creativa e suggerisci un esperimento concreto e originale, con pochi strumenti.");
        }
        if (hits(s, "disco elysium", "dave the diver", "gta 6", "grand theft auto vi",
                "last z", "solo leveling")) {
            return new Suggestion("Gaming", "C'è qualcosa che potrebbe interessarti su un gioco che segui.",
                "Commenta questo contenuto sul gioco senza anticipazioni non richieste e dimmi se contiene consigli utili.");
        }
        return null;
    }

    private static boolean hits(String s, String... terms) {
        for (String t : terms) if (s.contains(t)) return true;
        return false;
    }

    private LocalRules() { }
}
