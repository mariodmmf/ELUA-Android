package it.spunto.companion;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Elua UI 2026 tokens: no runtime dependencies, no data collection. */
final class EluaStyle {
    static final int BG = Color.rgb(12, 17, 24);
    static final int SURFACE = Color.rgb(24, 31, 40);
    static final int SURFACE_2 = Color.rgb(32, 41, 52);
    static final int BORDER = Color.rgb(54, 66, 78);
    static final int TEXT = Color.rgb(245, 245, 237);
    static final int SUBTEXT = Color.rgb(165, 178, 185);
    static final int FAINT = Color.rgb(117, 134, 144);
    static final int MINT = Color.rgb(170, 226, 205);
    static final int AMBER = Color.rgb(255, 192, 128);
    static final int DANGER = Color.rgb(255, 153, 145);
    static final int DEEP = Color.rgb(40, 59, 68);

    static int dp(Context context, float n) {
        return (int) (context.getResources().getDisplayMetrics().density * n + 0.5f);
    }
    static GradientDrawable panel(Context c, int fill, int stroke, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(c, radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(c, 1), stroke);
        return d;
    }
    static GradientDrawable gradient(Context c, int a, int b, float radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a,b});
        d.setCornerRadius(dp(c, radius));
        return d;
    }
    static TextView text(Context c, String value, float size, int color, boolean strong) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setFontFeatureSettings("kern");
        t.setLineSpacing(dp(c, 3), 1.02f);
        if (strong) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }
    static TextView wordmark(Context c, float size) {
        TextView mark = text(c, "elua.", size, TEXT, true);
        android.text.SpannableString styled = new android.text.SpannableString("elua.");
        styled.setSpan(new android.text.style.ForegroundColorSpan(MINT), 4, 5,
            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        mark.setText(styled);
        mark.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        mark.setLetterSpacing(-.055f);
        mark.setContentDescription("Elua");
        return mark;
    }
    static TextView kicker(Context c, String value, int color) {
        TextView t = text(c, value, 11, color, true);
        t.setLetterSpacing(.14f);
        return t;
    }
    static Button button(Context c, String name, boolean primary) {
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(name);
        b.setTextSize(13.5f);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setTextColor(primary ? BG : TEXT);
        b.setBackground(panel(c, primary ? MINT : SURFACE_2, primary ? Color.TRANSPARENT : BORDER, 16));
        b.setMinHeight(dp(c, 50));
        b.setMinimumHeight(dp(c, 50));
        b.setPadding(dp(c, 15), 0, dp(c, 15), 0);
        b.setStateListAnimator(null);
        b.setElevation(0);
        b.setGravity(Gravity.CENTER);
        return b;
    }
    static View gap(Context c, int height) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, height)));
        return v;
    }
    static LinearLayout card(Context c, int padding) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, padding), dp(c, padding), dp(c, padding), dp(c, padding));
        l.setBackground(panel(c, SURFACE, BORDER, 24));
        return l;
    }
    static ColorStateList tint(int color) {
        return ColorStateList.valueOf(color);
    }
    private EluaStyle() {}
}
